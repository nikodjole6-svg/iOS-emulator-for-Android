# iOS Emulator (Termux + VNC)

Simple Android app that controls QEMU-iOS (https://github.com/devos50/qemu-ios, iPod Touch 2G)
inside Termux and shows it through a built-in VNC viewer.

## Get the APK (no Android Studio needed)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo > Actions > "Build APK" > run it (or it runs on push).
3. Download the `ios-emulator-apk` artifact, unzip, install `app-debug.apk`.

## One-time phone setup
1. Install **Termux from F-Droid or GitHub** (not the old Play Store build).
2. Android settings > Apps > Termux > allow "Display over other apps".
3. Open this app > **Allow Termux** (copies a command; paste it in Termux, press Enter).
4. Back in the app, tap **Setup** and accept the "Run commands in Termux" permission.
   Setup builds QEMU (long, ~6 GB free needed) and downloads the boot files.

## Use
**Start** > wait a few seconds > **Connect**. Touch = mouse. **Stop** ends the emulator.
