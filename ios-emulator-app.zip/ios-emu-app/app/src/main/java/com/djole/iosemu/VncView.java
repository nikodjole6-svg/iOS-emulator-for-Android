package com.djole.iosemu;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Minimal VNC (RFB 3.8) client: no authentication, Raw encoding only,
 * which is what QEMU's built-in "-vnc" server offers by default.
 */
public class VncView extends View {

    public interface StatusListener {
        void onStatus(String text);
    }

    private final Object bmpLock = new Object();
    private Bitmap bmp;
    private int fbW, fbH;

    private volatile boolean running;
    private volatile Socket sock;
    private volatile OutputStream out;
    private Thread thread;
    private ExecutorService writer = Executors.newSingleThreadExecutor();

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();
    private StatusListener listener;

    public VncView(Context c) {
        super(c);
        textPaint.setColor(Color.GRAY);
        textPaint.setTextSize(40f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        setBackgroundColor(Color.BLACK);
    }

    public void setStatusListener(StatusListener l) {
        listener = l;
    }

    private void status(final String s) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (listener != null) listener.onStatus(s);
            }
        });
    }

    /** Connects (retrying for up to about 2 minutes while the emulator boots). */
    public synchronized void connect(final String host, final int port) {
        disconnect();
        running = true;
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                session(host, port);
            }
        }, "vnc-reader");
        thread.start();
    }

    public synchronized void disconnect() {
        running = false;
        Socket s = sock;
        if (s != null) {
            try {
                s.close();
            } catch (IOException ignored) {
            }
        }
        sock = null;
        out = null;
    }

    private void session(String host, int port) {
        Socket s = null;
        try {
            int attempt = 0;
            while (running && s == null) {
                attempt++;
                Socket t = new Socket();
                try {
                    t.connect(new InetSocketAddress(host, port), 2000);
                    s = t;
                } catch (IOException e) {
                    try {
                        t.close();
                    } catch (IOException ignored) {
                    }
                    if (attempt >= 60) {
                        throw new IOException("Nothing is listening on " + host + ":" + port
                                + ". Is the emulator started?");
                    }
                    status("Waiting for emulator... (" + attempt + ")");
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException ie) {
                        return;
                    }
                }
            }
            if (s == null) return;

            s.setTcpNoDelay(true);
            sock = s;
            DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 1 << 16));
            final OutputStream o = new BufferedOutputStream(s.getOutputStream(), 1 << 14);
            out = o;

            // --- handshake ---
            byte[] ver = new byte[12];
            in.readFully(ver);
            o.write("RFB 003.008\n".getBytes("US-ASCII"));
            o.flush();

            int nTypes = in.readUnsignedByte();
            if (nTypes == 0) {
                int len = in.readInt();
                byte[] reason = new byte[Math.max(0, Math.min(len, 4096))];
                in.readFully(reason);
                throw new IOException("Server refused: " + new String(reason, "US-ASCII"));
            }
            byte[] types = new byte[nTypes];
            in.readFully(types);
            boolean none = false;
            for (byte t : types) {
                if (t == 1) none = true;
            }
            if (!none) throw new IOException("VNC server wants a password (not supported)");
            o.write(1);
            o.flush();
            if (in.readInt() != 0) throw new IOException("VNC security handshake failed");

            o.write(1); // ClientInit: shared
            o.flush();

            int w = in.readUnsignedShort();
            int h = in.readUnsignedShort();
            in.readFully(new byte[16]); // server pixel format (we override it)
            int nameLen = in.readInt();
            in.readFully(new byte[Math.max(0, Math.min(nameLen, 65536))]);

            synchronized (bmpLock) {
                bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                bmp.eraseColor(Color.BLACK);
                fbW = w;
                fbH = h;
            }

            // SetPixelFormat: 32 bpp, depth 24, little endian, true colour, RGB 8/8/8 at 16/8/0
            byte[] pf = new byte[20];
            pf[0] = 0;
            pf[4] = 32;
            pf[5] = 24;
            pf[6] = 0;
            pf[7] = 1;
            pf[9] = (byte) 255;
            pf[11] = (byte) 255;
            pf[13] = (byte) 255;
            pf[14] = 16;
            pf[15] = 8;
            pf[16] = 0;
            o.write(pf);
            // SetEncodings: Raw only
            o.write(new byte[]{2, 0, 0, 1, 0, 0, 0, 0});
            o.flush();
            requestUpdate(false);
            status("Connected (" + w + "x" + h + ")");
            postInvalidate();

            // --- main loop ---
            byte[] row = new byte[0];
            int[] px = new int[0];
            while (running) {
                int type = in.readUnsignedByte();
                if (type == 0) { // FramebufferUpdate
                    in.readUnsignedByte();
                    int rects = in.readUnsignedShort();
                    for (int i = 0; i < rects; i++) {
                        int x = in.readUnsignedShort();
                        int y = in.readUnsignedShort();
                        int rw = in.readUnsignedShort();
                        int rh = in.readUnsignedShort();
                        int enc = in.readInt();
                        if (enc != 0) throw new IOException("Unsupported VNC encoding " + enc);
                        if (row.length < rw * 4) {
                            row = new byte[rw * 4];
                            px = new int[rw];
                        }
                        for (int yy = 0; yy < rh; yy++) {
                            in.readFully(row, 0, rw * 4);
                            for (int xx = 0; xx < rw; xx++) {
                                int b = row[xx * 4] & 0xFF;
                                int g = row[xx * 4 + 1] & 0xFF;
                                int r = row[xx * 4 + 2] & 0xFF;
                                px[xx] = 0xFF000000 | (r << 16) | (g << 8) | b;
                            }
                            synchronized (bmpLock) {
                                if (bmp != null && x >= 0 && y + yy >= 0
                                        && x + rw <= bmp.getWidth() && y + yy < bmp.getHeight()) {
                                    bmp.setPixels(px, 0, rw, x, y + yy, rw, 1);
                                }
                            }
                        }
                    }
                    postInvalidate();
                    requestUpdate(true);
                } else if (type == 1) { // SetColourMapEntries (unused with true colour)
                    in.readUnsignedByte();
                    in.readUnsignedShort();
                    int n = in.readUnsignedShort();
                    in.readFully(new byte[n * 6]);
                } else if (type == 2) { // Bell
                    // ignore
                } else if (type == 3) { // ServerCutText
                    in.readFully(new byte[3]);
                    int len = in.readInt();
                    in.readFully(new byte[Math.max(0, Math.min(len, 1 << 20))]);
                } else {
                    throw new IOException("Unknown VNC message " + type);
                }
            }
        } catch (IOException e) {
            if (running) status("Disconnected: " + e.getMessage());
        } finally {
            running = false;
            if (s != null) {
                try {
                    s.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private void requestUpdate(boolean incremental) {
        int w, h;
        synchronized (bmpLock) {
            w = fbW;
            h = fbH;
        }
        byte[] m = new byte[10];
        m[0] = 3;
        m[1] = (byte) (incremental ? 1 : 0);
        m[6] = (byte) (w >> 8);
        m[7] = (byte) w;
        m[8] = (byte) (h >> 8);
        m[9] = (byte) h;
        send(m);
    }

    private void send(final byte[] data) {
        final OutputStream o = out;
        if (o == null) return;
        writer.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    synchronized (o) {
                        o.write(data);
                        o.flush();
                    }
                } catch (IOException ignored) {
                }
            }
        });
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        synchronized (bmpLock) {
            if (bmp == null) {
                canvas.drawText("Not connected", getWidth() / 2f, getHeight() / 2f, textPaint);
                return;
            }
            float scale = Math.min((float) getWidth() / fbW, (float) getHeight() / fbH);
            float dw = fbW * scale;
            float dh = fbH * scale;
            float left = (getWidth() - dw) / 2f;
            float top = (getHeight() - dh) / 2f;
            src.set(0, 0, fbW, fbH);
            dst.set(left, top, left + dw, top + dh);
            canvas.drawBitmap(bmp, src, dst, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int w, h;
        synchronized (bmpLock) {
            w = fbW;
            h = fbH;
        }
        if (w == 0 || h == 0 || out == null) return true;

        float scale = Math.min((float) getWidth() / w, (float) getHeight() / h);
        float left = (getWidth() - w * scale) / 2f;
        float top = (getHeight() - h * scale) / 2f;
        int x = Math.round((ev.getX() - left) / scale);
        int y = Math.round((ev.getY() - top) / scale);
        x = Math.max(0, Math.min(w - 1, x));
        y = Math.max(0, Math.min(h - 1, y));

        int action = ev.getActionMasked();
        int mask;
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            mask = 1;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            mask = 0;
        } else {
            return true;
        }
        send(new byte[]{5, (byte) mask, (byte) (x >> 8), (byte) x, (byte) (y >> 8), (byte) y});
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        disconnect();
        super.onDetachedFromWindow();
    }
}
