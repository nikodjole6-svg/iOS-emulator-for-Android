package com.djole.iosemu;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {

    private static final String TERMUX_PKG = "com.termux";
    private static final String TERMUX_PERM = "com.termux.permission.RUN_COMMAND";
    private static final String TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash";
    private static final String TERMUX_HOME = "/data/data/com.termux/files/home";
    private static final String ENABLE_CMD =
            "mkdir -p ~/.termux; grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null"
                    + " || echo 'allow-external-apps=true' >> ~/.termux/termux.properties;"
                    + " termux-reload-settings; echo DONE";

    // If ~/ios-qemu-custom.sh exists in Termux, run that instead of the bundled script.
    private static final String OVERRIDE_PREFIX =
            "if [ -f \"$HOME/ios-qemu-custom.sh\" ]; then exec bash \"$HOME/ios-qemu-custom.sh\" \"$@\"; fi\n";

    // X11 keysym for the Home key (sent over VNC when the on-screen home button is tapped).
    private static final int KEYSYM_HOME = 0xFF50;

    // Palette
    private static final int BG = 0xFF0E1014;
    private static final int CARD = 0xFF181B22;
    private static final int TEXT = 0xFFF2F4F8;
    private static final int MUTED = 0xFF8B93A3;
    private static final int BLUE = 0xFF2F6FED;
    private static final int GREEN = 0xFF1F9D55;
    private static final int RED = 0xFFD64545;
    private static final int INDIGO = 0xFF5B5BD6;
    private static final int GRAY = 0xFF2A2F3A;

    private TextView statusView;
    private View statusDot;
    private LinearLayout controlsPanel;
    private Button toggleButton;
    private VncView vnc;
    private String pendingAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));

        // ---- header: title + status + controls toggle ----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        statusDot = new View(this);
        setDot(MUTED);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(10), dp(10));
        dotLp.rightMargin = dp(8);
        titleRow.addView(statusDot, dotLp);

        TextView title = new TextView(this);
        title.setText("iPod Touch");
        title.setTextColor(TEXT);
        title.setTextSize(20f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleRow.addView(title);
        titleCol.addView(titleRow);

        statusView = new TextView(this);
        statusView.setTextColor(MUTED);
        statusView.setTextSize(12f);
        statusView.setMaxLines(3);
        statusView.setText("Ready. Open Controls to set up.");
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stLp.topMargin = dp(2);
        titleCol.addView(statusView, stLp);

        header.addView(titleCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        toggleButton = pill("Controls", GRAY, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPanelVisible(controlsPanel.getVisibility() != View.VISIBLE);
            }
        });
        header.addView(toggleButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)));
        root.addView(header);

        // ---- controls card ----
        controlsPanel = new LinearLayout(this);
        controlsPanel.setOrientation(LinearLayout.VERTICAL);
        controlsPanel.setBackground(rounded(CARD, dp(18), 0, 0));
        controlsPanel.setPadding(dp(8), dp(8), dp(8), dp(8));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(pill("1  Allow Termux", GRAY, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allowTermux();
            }
        }), cell());
        row1.addView(pill("2  Setup (once)", BLUE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                termux("setup", false, "0");
            }
        }), cell());
        controlsPanel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(pill("3  Start", GREEN, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                termux("run", false, "2");
                status("Starting emulator... tap Connect in a few seconds.", MUTED);
            }
        }), cell());
        row2.addView(pill("4  Connect", INDIGO, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vnc.connect("127.0.0.1", 5901);
            }
        }), cell());
        row2.addView(pill("Stop", RED, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vnc.disconnect();
                termux("stop", true, "3");
                status("Stopped.", MUTED);
            }
        }), cell());
        controlsPanel.addView(row2);

        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cpLp.topMargin = dp(12);
        root.addView(controlsPanel, cpLp);

        // ---- device frame: screen + home button ----
        LinearLayout device = new LinearLayout(this);
        device.setOrientation(LinearLayout.VERTICAL);
        device.setGravity(Gravity.CENTER_HORIZONTAL);
        device.setBackground(rounded(0xFF050506, dp(38), dp(2), 0xFF2B2E36));
        device.setPadding(dp(14), dp(18), dp(14), dp(10));

        vnc = new VncView(this);
        vnc.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundedRect(0, 0, view.getWidth(), view.getHeight(), dp(8));
            }
        });
        vnc.setClipToOutline(true);
        vnc.setStatusListener(new VncView.StatusListener() {
            @Override
            public void onStatus(String text) {
                boolean ok = text.startsWith("Connected");
                status(text, ok ? GREEN : (text.startsWith("Disconnected") ? RED : MUTED));
                if (ok) setPanelVisible(false);
            }
        });
        device.addView(vnc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        ImageView home = new ImageView(this);
        home.setImageResource(R.drawable.home_button);
        home.setScaleType(ImageView.ScaleType.FIT_CENTER);
        home.setContentDescription("Home button");
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (vnc.isConnected()) {
                    vnc.pressKey(KEYSYM_HOME);
                } else {
                    Toast.makeText(MainActivity.this, "Not connected yet.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        LinearLayout.LayoutParams homeLp = new LinearLayout.LayoutParams(dp(60), dp(60));
        homeLp.topMargin = dp(10);
        device.addView(home, homeLp);

        LinearLayout.LayoutParams devLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        devLp.topMargin = dp(12);
        root.addView(device, devLp);

        setContentView(root);
    }

    // ---------- UI helpers ----------

    private GradientDrawable rounded(int fill, int radius, int strokeWidth, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor);
        return d;
    }

    private Button pill(String text, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setStateListAnimator(null);
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        b.setBackground(rounded(color, dp(14), 0, 0));
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams cell() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, dp(46), 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        return lp;
    }

    private void setDot(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        statusDot.setBackground(d);
    }

    private void setPanelVisible(boolean visible) {
        controlsPanel.setVisibility(visible ? View.VISIBLE : View.GONE);
        toggleButton.setText(visible ? "Hide" : "Controls");
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void status(String s, int dotColor) {
        statusView.setText(s);
        setDot(dotColor);
    }

    // ---------- Termux ----------

    private boolean termuxInstalled() {
        try {
            getPackageManager().getPackageInfo(TERMUX_PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /** Copies the one-time Termux setting command and opens Termux so it can be pasted. */
    private void allowTermux() {
        if (!termuxInstalled()) {
            Toast.makeText(this, "Install Termux from F-Droid or GitHub first.", Toast.LENGTH_LONG).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("termux-cmd", ENABLE_CMD));
        status("Command copied. Paste it in Termux, press Enter, then come back and tap Setup.", MUTED);
        Toast.makeText(this, "Copied. Paste it in Termux and press Enter.", Toast.LENGTH_LONG).show();
        Intent launch = getPackageManager().getLaunchIntentForPackage(TERMUX_PKG);
        if (launch != null) startActivity(launch);
    }

    private String readScript() throws Exception {
        InputStream in = getAssets().open("ios-qemu.sh");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toString("UTF-8");
    }

    /**
     * Runs the bundled script inside Termux.
     * sessionAction: "0" open Termux and show it, "2" run in a Termux session without
     * switching to it, "3" same but keep the current session (used with background=true).
     */
    private void termux(String action, boolean background, String sessionAction) {
        if (!termuxInstalled()) {
            Toast.makeText(this, "Install Termux from F-Droid or GitHub first.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(TERMUX_PERM) != PackageManager.PERMISSION_GRANTED) {
            pendingAction = action + "|" + background + "|" + sessionAction;
            requestPermissions(new String[]{TERMUX_PERM}, 1);
            return;
        }
        try {
            Intent i = new Intent();
            i.setClassName(TERMUX_PKG, "com.termux.app.RunCommandService");
            i.setAction("com.termux.RUN_COMMAND");
            i.putExtra("com.termux.RUN_COMMAND_PATH", TERMUX_BASH);
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",
                    new String[]{"-c", OVERRIDE_PREFIX + readScript(), "ios-qemu", action});
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME);
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", background);
            i.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", sessionAction);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
            if (action.equals("setup")) {
                status("Setup is running in Termux (long). Return here when it says finished.", MUTED);
            }
        } catch (Exception e) {
            status("Could not talk to Termux: " + e.getMessage()
                    + "  (Did you tap Allow Termux and run the command?)", RED);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && pendingAction != null) {
            String[] p = pendingAction.split("\\|");
            pendingAction = null;
            termux(p[0], Boolean.parseBoolean(p[1]), p[2]);
        } else {
            status("Permission denied. Enable 'Run commands in Termux environment' in this app's"
                    + " Android permission settings.", RED);
        }
    }
}
