package com.djole.iosemu;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {

    private static final String TERMUX_PKG = "com.termux";
    private static final String TERMUX_PERM = "com.termux.permission.RUN_COMMAND";
    private static final String TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash";
    private static final String TERMUX_HOME = "/data/data/com.termux/files/home";
    private static final String ENABLE_CMD =
            "mkdir -p ~/.termux; grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null"
                    + " || echo 'allow-external-apps=true' >> ~/.termux/termux.properties;"
                    + " termux-reload-settings; echo DONE";

    private TextView statusView;
    private VncView vnc;
    private String pendingAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        int pad = dp(8);
        root.setPadding(pad, pad, pad, pad);

        statusView = new TextView(this);
        statusView.setTextColor(Color.LTGRAY);
        statusView.setTextSize(13f);
        statusView.setText("1) Allow Termux  2) Setup (once)  3) Start  4) Connect");
        root.addView(statusView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(button("Allow Termux", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allowTermux();
            }
        }), weighted());
        row1.addView(button("Setup", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                termux("setup", false, "0");
            }
        }), weighted());
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(button("Start", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                termux("run", false, "2");
                status("Starting emulator... press Connect in a few seconds.");
            }
        }), weighted());
        row2.addView(button("Connect", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vnc.connect("127.0.0.1", 5901);
            }
        }), weighted());
        row2.addView(button("Stop", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vnc.disconnect();
                termux("stop", true, "3");
                status("Stopped.");
            }
        }), weighted());
        root.addView(row2);

        vnc = new VncView(this);
        vnc.setStatusListener(new VncView.StatusListener() {
            @Override
            public void onStatus(String text) {
                status(text);
            }
        });
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        vp.topMargin = dp(6);
        root.addView(vnc, vp);

        setContentView(root);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void status(String s) {
        statusView.setText(s);
    }

    private boolean termuxInstalled() {
        try {
            getPackageManager().getPackageInfo(TERMUX_PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /** Copies the one-time Termux setting command and opens Termux so it can be pasted. */
    private void allowTermux() {
        if (!termuxInstalled()) {
            Toast.makeText(this, "Install Termux from F-Droid or GitHub first.", Toast.LENGTH_LONG).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("termux-cmd", ENABLE_CMD));
        status("Command copied. Paste it in Termux, press Enter, then come back and tap Setup.");
        Toast.makeText(this, "Copied. Paste it in Termux and press Enter.", Toast.LENGTH_LONG).show();
        Intent launch = getPackageManager().getLaunchIntentForPackage(TERMUX_PKG);
        if (launch != null) startActivity(launch);
    }

    private String readScript() throws Exception {
        InputStream in = getAssets().open("ios-qemu.sh");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toString("UTF-8");
    }

    /**
     * Runs the bundled script inside Termux.
     * sessionAction: "0" open Termux and show it, "2" run in a Termux session without
     * switching to it, "3" same but keep the current session (used with background=true).
     */
    private void termux(String action, boolean background, String sessionAction) {
        if (!termuxInstalled()) {
            Toast.makeText(this, "Install Termux from F-Droid or GitHub first.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(TERMUX_PERM) != PackageManager.PERMISSION_GRANTED) {
            pendingAction = action + "|" + background + "|" + sessionAction;
            requestPermissions(new String[]{TERMUX_PERM}, 1);
            return;
        }
        try {
            Intent i = new Intent();
            i.setClassName(TERMUX_PKG, "com.termux.app.RunCommandService");
            i.setAction("com.termux.RUN_COMMAND");
            i.putExtra("com.termux.RUN_COMMAND_PATH", TERMUX_BASH);
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",
                    new String[]{"-c", readScript(), "ios-qemu", action});
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME);
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", background);
            i.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", sessionAction);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
            if (action.equals("setup")) {
                status("Setup is running in Termux (long). Return here when it says finished.");
            }
        } catch (Exception e) {
            status("Could not talk to Termux: " + e.getMessage()
                    + "  (Did you tap Allow Termux and run the command?)");
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && pendingAction != null) {
            String[] p = pendingAction.split("\\|");
            pendingAction = null;
            termux(p[0], Boolean.parseBoolean(p[1]), p[2]);
        } else {
            status("Permission denied. Enable 'Run commands in Termux environment' in this app's"
                    + " Android permission settings.");
        }
    }
}
