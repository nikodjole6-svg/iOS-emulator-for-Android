package com.djole.iosemu;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {

    private static final String TERMUX_PKG = "com.termux";
    private static final String TERMUX_PERM = "com.termux.permission.RUN_COMMAND";
    private static final String TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash";
    private static final String TERMUX_HOME = "/data/data/com.termux/files/home";
    private static final String ENABLE_CMD =
            "mkdir -p ~/.termux; grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null"
                    + " || echo 'allow-external-apps=true' >> ~/.termux/termux.properties;"
                    + " termux-reload-settings; echo DONE";

    // If ~/ios-qemu-custom.sh exists in Termux, run that instead of the bundled script.
    private static final String OVERRIDE_PREFIX =
            "if [ -f \"$HOME/ios-qemu-custom.sh\" ]; then exec bash \"$HOME/ios-qemu-custom.sh\" \"$@\"; fi\n";

    // X11 keysym for the Home key (sent over VNC when the on-screen home button is tapped).
    private static final int KEYSYM_HOME = 0xFF50;

    // Palette
    // Theme colors (set by applyTheme)
    private int BG, CARD, TEXT, MUTED, GRAY, STROKE;
    private static final int BLUE = 0xFF2F6FED;
    private static final int GREEN = 0xFF1F9D55;
    private static final int RED = 0xFFD64545;
    private static final int INDIGO = 0xFF5B5BD6;

    private SharedPreferences prefs;
    private String model = "2g";
    private String theme = "dark";
    private TextView titleView;
    private TextView statusView;
    private View statusDot;
    private LinearLayout controlsPanel;
    private Button toggleButton;
    private VncView vnc;
    private String pendingAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("ios_emulator", MODE_PRIVATE);
        model = prefs.getString("model", "2g");
        theme = prefs.getString("theme", "dark");
        applyTheme();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));

        // ---- header: title + status + controls toggle ----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        statusDot = new View(this);
        setDot(MUTED);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(10), dp(10));
        dotLp.rightMargin = dp(8);
        titleRow.addView(statusDot, dotLp);

        titleView = new TextView(this);
        titleView.setText(modelName());
        titleView.setTextColor(TEXT);
        titleView.setTextSize(18f);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleRow.addView(titleView);
        titleCol.addView(titleRow);

        statusView = new TextView(this);
        statusView.setTextColor(MUTED);
        statusView.setTextSize(12f);
        statusView.setMaxLines(3);
        statusView.setText("Ready");
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stLp.topMargin = dp(2);
        titleCol.addView(statusView, stLp);

        header.addView(titleCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button settingsButton = pill("Settings", GRAY, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        settingsButton.setTextSize(13f);
        LinearLayout.LayoutParams setLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
        setLp.rightMargin = dp(6);
        header.addView(settingsButton, setLp);

        toggleButton = pill("Controls", GRAY, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPanelVisible(controlsPanel.getVisibility() != View.VISIBLE);
            }
        });
        toggleButton.setTextSize(13f);
        header.addView(toggleButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)));
        root.addView(header);

        // ---- controls card ----
        controlsPanel = new LinearLayout(this);
        controlsPanel.setOrientation(LinearLayout.VERTICAL);
        controlsPanel.setBackground(rounded(CARD, dp(18), 0, 0));
        controlsPanel.setPadding(dp(8), dp(8), dp(8), dp(8));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(pill("Allow Termux", GRAY, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allowTermux();
            }
        }), cell());
        row1.addView(pill("Setup", BLUE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                termux("setup", false, "0");
            }
        }), cell());
        controlsPanel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(pill("Start", GREEN, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                termux("run", false, "2");
                status("Starting emulator... tap Connect in a few seconds.", MUTED);
            }
        }), cell());
        row2.addView(pill("Connect", INDIGO, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vnc.connect("127.0.0.1", 5901);
            }
        }), cell());
        row2.addView(pill("Stop", RED, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vnc.disconnect();
                termux("stop", true, "3");
                status("Stopped.", MUTED);
            }
        }), cell());
        controlsPanel.addView(row2);

        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cpLp.topMargin = dp(12);
        root.addView(controlsPanel, cpLp);

        // ---- device body with iPod Touch 2G proportions (61.8 x 110 mm) ----
        AspectLayout device = new AspectLayout(this, 61.8f / 110f);
        device.setOrientation(LinearLayout.VERTICAL);
        device.setBackground(rounded(0xFF060607, dp(40), dp(2), STROKE));

        vnc = new VncView(this);
        vnc.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(2));
            }
        });
        vnc.setClipToOutline(true);
        vnc.setStatusListener(new VncView.StatusListener() {
            @Override
            public void onStatus(String text) {
                boolean ok = text.startsWith("Connected");
                status(text, ok ? GREEN : (text.startsWith("Disconnected") ? RED : MUTED));
                if (ok) setPanelVisible(false);
            }
        });
        // 3.5" screen is 80 mm tall of the 110 mm body; the rest below is the home button area.
        device.addView(vnc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 80f));

        FrameLayout homeArea = new FrameLayout(this);
        ImageView home = new ImageView(this);
        home.setImageResource(R.drawable.home_button);
        home.setScaleType(ImageView.ScaleType.FIT_CENTER);
        home.setContentDescription("Home button");
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (vnc.isConnected()) {
                    vnc.pressKey(KEYSYM_HOME);
                } else {
                    Toast.makeText(MainActivity.this, "Not connected yet.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        homeArea.addView(home, new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER));
        device.addView(homeArea, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 19f));
        device.setHomeView(home);

        LinearLayout.LayoutParams devLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        devLp.topMargin = dp(12);
        devLp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(device, devLp);

        setContentView(root);
    }

    // ---------- theme + settings ----------

    private String modelName() {
        return "1g".equals(model) ? "iPod Touch 1G" : "iPod Touch 2G";
    }

    private void applyTheme() {
        boolean light = "light".equals(theme);
        if (light) {
            BG = 0xFFF2F4F8;
            CARD = 0xFFFFFFFF;
            TEXT = 0xFF14161B;
            MUTED = 0xFF5F6676;
            GRAY = 0xFF6B7385;
            STROKE = 0xFFB9BFCB;
        } else if ("amoled".equals(theme)) {
            BG = 0xFF000000;
            CARD = 0xFF0C0C0E;
            TEXT = 0xFFF2F4F8;
            MUTED = 0xFF8B93A3;
            GRAY = 0xFF1E1F23;
            STROKE = 0xFF26272C;
        } else {
            BG = 0xFF0E1014;
            CARD = 0xFF181B22;
            TEXT = 0xFFF2F4F8;
            MUTED = 0xFF8B93A3;
            GRAY = 0xFF2A2F3A;
            STROKE = 0xFF3A3D45;
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = 0;
            if (light) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private RadioButton radio(String text) {
        RadioButton rb = new RadioButton(this);
        rb.setText(text);
        rb.setTextColor(TEXT);
        rb.setTextSize(16f);
        rb.setId(View.generateViewId());
        rb.setButtonTintList(ColorStateList.valueOf(BLUE));
        rb.setPadding(dp(8), dp(10), dp(8), dp(10));
        return rb;
    }

    private void showSettings() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(rounded(CARD, dp(22), 0, 0));
        box.setPadding(dp(20), dp(18), dp(20), dp(14));

        box.addView(label("Settings", 20f, TEXT, true));

        TextView devHead = label("Device (ROM)", 13f, MUTED, true);
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hLp.topMargin = dp(16);
        box.addView(devHead, hLp);

        RadioGroup devGroup = new RadioGroup(this);
        devGroup.setOrientation(RadioGroup.VERTICAL);
        final RadioButton rb1 = radio("iPod Touch 1G");
        final RadioButton rb2 = radio("iPod Touch 2G");
        devGroup.addView(rb1);
        devGroup.addView(rb2);
        devGroup.check("1g".equals(model) ? rb1.getId() : rb2.getId());
        devGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int id) {
                String m = (id == rb1.getId()) ? "1g" : "2g";
                if (!m.equals(model)) {
                    model = m;
                    prefs.edit().putString("model", m).apply();
                    titleView.setText(modelName());
                    vnc.disconnect();
                    status(modelName() + " selected. Open Controls: Setup (first time), then Start.", MUTED);
                }
            }
        });
        box.addView(devGroup);

        TextView themeHead = label("Theme", 13f, MUTED, true);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tLp.topMargin = dp(14);
        box.addView(themeHead, tLp);

        RadioGroup themeGroup = new RadioGroup(this);
        themeGroup.setOrientation(RadioGroup.VERTICAL);
        final RadioButton tLight = radio("Light");
        final RadioButton tDark = radio("Dark");
        final RadioButton tAmoled = radio("AMOLED (pure black)");
        themeGroup.addView(tLight);
        themeGroup.addView(tDark);
        themeGroup.addView(tAmoled);
        themeGroup.check("light".equals(theme) ? tLight.getId()
                : ("amoled".equals(theme) ? tAmoled.getId() : tDark.getId()));
        themeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int id) {
                String t = (id == tLight.getId()) ? "light" : (id == tAmoled.getId() ? "amoled" : "dark");
                if (!t.equals(theme)) {
                    prefs.edit().putString("theme", t).apply();
                    d.dismiss();
                    recreate();
                }
            }
        });
        box.addView(themeGroup);

        TextView note = label("Each device needs Setup once (long). Press Stop before switching devices.",
                12f, MUTED, false);
        LinearLayout.LayoutParams nLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nLp.topMargin = dp(12);
        box.addView(note, nLp);

        Button done = pill("Done", BLUE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        dLp.topMargin = dp(14);
        box.addView(done, dLp);

        d.setContentView(box);
        d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        d.show();
        d.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.9f),
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    // ---------- UI helpers ----------

    private GradientDrawable rounded(int fill, int radius, int strokeWidth, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor);
        return d;
    }

    private Button pill(String text, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setStateListAnimator(null);
        b.setSingleLine(true);
        b.setPadding(dp(6), dp(10), dp(6), dp(10));
        b.setBackground(rounded(color, dp(14), 0, 0));
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams cell() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, dp(46), 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        return lp;
    }

    private void setDot(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        statusDot.setBackground(d);
    }

    private void setPanelVisible(boolean visible) {
        controlsPanel.setVisibility(visible ? View.VISIBLE : View.GONE);
        toggleButton.setText(visible ? "Hide" : "Controls");
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void status(String s, int dotColor) {
        statusView.setText(s);
        setDot(dotColor);
    }

    // ---------- Termux ----------

    private boolean termuxInstalled() {
        try {
            getPackageManager().getPackageInfo(TERMUX_PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /** Copies the one-time Termux setting command and opens Termux so it can be pasted. */
    private void allowTermux() {
        if (!termuxInstalled()) {
            Toast.makeText(this, "Install Termux from F-Droid or GitHub first.", Toast.LENGTH_LONG).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("termux-cmd", ENABLE_CMD));
        status("Command copied. Paste it in Termux, press Enter, then come back and tap Setup.", MUTED);
        Toast.makeText(this, "Copied. Paste it in Termux and press Enter.", Toast.LENGTH_LONG).show();
        Intent launch = getPackageManager().getLaunchIntentForPackage(TERMUX_PKG);
        if (launch != null) startActivity(launch);
    }

    private String readScript() throws Exception {
        InputStream in = getAssets().open("ios-qemu.sh");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toString("UTF-8");
    }

    /**
     * Runs the bundled script inside Termux.
     * sessionAction: "0" open Termux and show it, "2" run in a Termux session without
     * switching to it, "3" same but keep the current session (used with background=true).
     */
    private void termux(String action, boolean background, String sessionAction) {
        if (!termuxInstalled()) {
            Toast.makeText(this, "Install Termux from F-Droid or GitHub first.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(TERMUX_PERM) != PackageManager.PERMISSION_GRANTED) {
            pendingAction = action + "|" + background + "|" + sessionAction;
            requestPermissions(new String[]{TERMUX_PERM}, 1);
            return;
        }
        try {
            Intent i = new Intent();
            i.setClassName(TERMUX_PKG, "com.termux.app.RunCommandService");
            i.setAction("com.termux.RUN_COMMAND");
            i.putExtra("com.termux.RUN_COMMAND_PATH", TERMUX_BASH);
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",
                    new String[]{"-c", OVERRIDE_PREFIX + readScript(), "ios-qemu", action, model});
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME);
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", background);
            i.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", sessionAction);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
            if (action.equals("setup")) {
                status("Setup is running in Termux (long). Return here when it says finished.", MUTED);
            }
        } catch (Exception e) {
            status("Could not talk to Termux: " + e.getMessage()
                    + "  (Did you tap Allow Termux and run the command?)", RED);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && pendingAction != null) {
            String[] p = pendingAction.split("\\|");
            pendingAction = null;
            termux(p[0], Boolean.parseBoolean(p[1]), p[2]);
        } else {
            status("Permission denied. Enable 'Run commands in Termux environment' in this app's"
                    + " Android permission settings.", RED);
        }
    }

    /** A vertical LinearLayout that keeps a fixed width:height ratio and scales its bezel. */
    private static class AspectLayout extends LinearLayout {
        private final float ratio;
        private View home;

        AspectLayout(Context c, float ratio) {
            super(c);
            this.ratio = ratio;
        }

        void setHomeView(View v) {
            home = v;
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int maxW = MeasureSpec.getSize(wSpec);
            int maxH = MeasureSpec.getSize(hSpec);
            int w = maxW;
            int h = Math.round(w / ratio);
            if (h > maxH) {
                h = maxH;
                w = Math.round(h * ratio);
            }
            super.onMeasure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            int px = Math.round(w * 0.068f);
            int pt = Math.round(h * 0.10f);
            if (getPaddingLeft() != px || getPaddingTop() != pt) {
                setPadding(px, pt, px, 0);
            }
            if (getBackground() instanceof GradientDrawable) {
                ((GradientDrawable) getBackground()).setCornerRadius(w * 0.12f);
            }
            if (home != null) {
                int d = Math.round(h * 0.105f);
                ViewGroup.LayoutParams lp = home.getLayoutParams();
                if (lp != null && lp.width != d) {
                    lp.width = d;
                    lp.height = d;
                    home.setLayoutParams(lp);
                }
            }
        }
    }
}
