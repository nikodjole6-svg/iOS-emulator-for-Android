#!/data/data/com.termux/files/usr/bin/bash
# Runs inside Termux. Started by the "iOS Emulator" app via Termux RUN_COMMAND.
# Actions: setup | run | stop
# Emulator: https://github.com/devos50/qemu-ios (branch ipod_touch_2g) - iPod Touch 2G
# Display: VNC on 127.0.0.1:5901 (QEMU "-vnc 127.0.0.1:1")

set -uo pipefail

BASE="$HOME/ios-qemu"
SRC="$BASE/qemu-ios"
ASSETS="$BASE/assets"
EXTRACT="$BASE/extract"
CONF="$BASE/paths.env"
PIDFILE="$BASE/qemu.pid"
TAG="n72ap_v1"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
RAM="${RAM:-2G}"
JOBS="${JOBS:-$(n=$(nproc); [ "$n" -gt 4 ] && echo 4 || echo "$n")}"

say()  { printf '\n==> %s\n' "$*"; }
fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

do_setup() {
  mkdir -p "$BASE"
  local free_kb
  free_kb=$(df -Pk "$BASE" | awk 'NR==2{print $4}')
  [ "${free_kb:-0}" -ge 6000000 ] || fail "Need about 6 GB free; only $((free_kb/1024)) MB available."

  say "Installing packages"
  export DEBIAN_FRONTEND=noninteractive
  pkg update -y || fail "pkg update failed"
  pkg upgrade -y -o Dpkg::Options::="--force-confnew" || fail "pkg upgrade failed"
  # Install one by one so a single missing package cannot abort everything.
  for p in git clang make ninja pkg-config python python-pip glib libpixman \
           openssl zlib curl unzip binutils; do
    pkg install -y "$p" || echo "WARNING: could not install $p"
  done
  for c in git clang make ninja python curl unzip; do
    command -v "$c" >/dev/null 2>&1 || fail "Required tool missing after install: $c"
  done
  # Build helpers (QEMU's configure normally brings its own meson; this is a fallback).
  pip install meson setuptools wheel || echo "WARNING: pip helpers not installed (continuing)"
  command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock || true

  say "Fetching source (branch ipod_touch_2g)"
  if [ -d "$SRC/.git" ]; then
    git -C "$SRC" pull --ff-only || true
  else
    git clone --depth 1 -b ipod_touch_2g https://github.com/devos50/qemu-ios.git "$SRC" \
      || fail "git clone failed"
  fi

  say "Configuring QEMU (arm-softmmu only, VNC display)"
  mkdir -p "$SRC/build"
  cd "$SRC/build" || fail "no build dir"
  ../configure \
    --target-list=arm-softmmu \
    --disable-capstone \
    --disable-slirp \
    --disable-docs \
    --disable-werror \
    --enable-pie \
    --extra-cflags="-I$PREFIX/include" \
    --extra-ldflags="-L$PREFIX/lib -lcrypto" \
    || fail "configure failed (scroll up for the reason)"

  say "Building with -j$JOBS (this takes a long time; keep your phone awake)"
  make -j"$JOBS" || fail "make failed (scroll up for the reason)"

  local q="$SRC/build/arm-softmmu/qemu-system-arm"
  [ -x "$q" ] || q="$SRC/build/qemu-system-arm"
  [ -x "$q" ] || fail "Build finished but qemu-system-arm was not found."

  say "Downloading boot files from release $TAG"
  mkdir -p "$ASSETS" "$EXTRACT"
  cd "$ASSETS" || fail "no assets dir"
  local urls u f z d
  urls=$(curl -fsSL "https://api.github.com/repos/devos50/qemu-ios/releases/tags/$TAG" \
         | grep -o '"browser_download_url": *"[^"]*"' | cut -d'"' -f4) \
    || fail "Could not read release info from GitHub."
  [ -n "$urls" ] || fail "Release has no downloadable assets."
  for u in $urls; do
    f="$(basename "$u")"
    if [ ! -s "$f" ]; then
      echo "  $f"
      curl -fL -o "$f" "$u" || fail "download failed: $f"
    fi
  done
  for z in *.zip; do
    [ -e "$z" ] || continue
    d="$EXTRACT/${z%.zip}"
    [ -d "$d" ] || { mkdir -p "$d"; unzip -oq "$z" -d "$d"; }
  done

  say "Locating bootrom / NAND / NOR"
  local bootrom nand nor
  bootrom=$(find "$ASSETS" "$EXTRACT" -type f -iname '*bootrom*' | head -n1 || true)
  nand=$(find "$EXTRACT" "$ASSETS" -type d -iname 'nand' | head -n1 || true)
  nor=$(find "$EXTRACT" "$ASSETS" -iname '*nor*' ! -iname '*.zip' | head -n1 || true)
  echo "  bootrom: ${bootrom:-NOT FOUND}"
  echo "  nand   : ${nand:-NOT FOUND}"
  echo "  nor    : ${nor:-NOT FOUND}"
  printf 'BOOTROM="%s"\nNAND="%s"\nNOR="%s"\n' "$bootrom" "$nand" "$nor" > "$CONF"
  if [ -z "$bootrom" ] || [ -z "$nand" ] || [ -z "$nor" ]; then
    echo
    echo "Could not auto-detect every file. Downloaded files:"
    ls -lR "$ASSETS" "$EXTRACT" | head -n 60
    fail "Fix the paths in $CONF by hand, then press Start in the app."
  fi

  say "Setup finished. Go back to the app and press Start."
}

do_run() {
  [ -f "$CONF" ] || fail "Run Setup first."
  # shellcheck disable=SC1090
  . "$CONF"
  [ -n "${BOOTROM:-}" ] && [ -n "${NAND:-}" ] && [ -n "${NOR:-}" ] || fail "Bad paths in $CONF"
  local q="$SRC/build/arm-softmmu/qemu-system-arm"
  [ -x "$q" ] || q="$SRC/build/qemu-system-arm"
  [ -x "$q" ] || fail "qemu-system-arm is not built. Run Setup."

  if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    fail "Emulator is already running (pid $(cat "$PIDFILE"))."
  fi
  command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock || true

  say "Starting emulator. VNC on 127.0.0.1:5901 - press Connect in the app."
  echo $$ > "$PIDFILE"
  exec "$q" \
    -M "iPod-Touch,bootrom=$BOOTROM,nand=$NAND,nor=$NOR" \
    -serial mon:stdio -cpu max -m "$RAM" -d unimp \
    -display none -vnc 127.0.0.1:1
}

do_stop() {
  if [ -f "$PIDFILE" ]; then
    kill "$(cat "$PIDFILE")" 2>/dev/null || true
    rm -f "$PIDFILE"
  fi
  command -v pkill >/dev/null 2>&1 && pkill -f qemu-system-arm 2>/dev/null || true
  command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock || true
  echo "Stopped."
}

case "${1:-}" in
  setup) do_setup ;;
  run)   do_run ;;
  stop)  do_stop ;;
  *)     echo "usage: setup | run | stop"; exit 1 ;;
esac
