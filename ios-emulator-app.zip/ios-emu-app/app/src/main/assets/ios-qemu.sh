#!/data/data/com.termux/files/usr/bin/bash
# Runs inside Termux. Started by the "iOS Emulator" app via Termux RUN_COMMAND.
# Usage: setup|run|stop [1g|2g]
# Emulator: https://github.com/devos50/qemu-ios  (iPod Touch 1G / 2G)
# Display: VNC on 127.0.0.1:5901 (QEMU "-vnc 127.0.0.1:1")
#
# Setup is safe to press again at any time: finished steps are skipped.

set -uo pipefail

MODEL="${2:-2g}"
case "$MODEL" in
  1g) NAME="iPod Touch 1G"; BRANCH="ipod_touch_1g"; TAG="n45ap_v1"; SUF="-1g"; RAM_DEFAULT="1G" ;;
  *)  MODEL="2g"; NAME="iPod Touch 2G"; BRANCH="ipod_touch_2g"; TAG="n72ap_v1"; SUF=""; RAM_DEFAULT="2G" ;;
esac

BASE="$HOME/ios-qemu"
SRC="$BASE/qemu-ios$SUF"
ASSETS="$BASE/assets$SUF"
EXTRACT="$BASE/extract$SUF"
CONF="$BASE/paths$SUF.env"
LOG="$BASE/build$SUF.log"
CFGLOG="$BASE/configure$SUF.log"
ERRFILE="$BASE/build-errors$SUF.txt"
MARK="$BASE/.configured-v3$SUF"
PIDFILE="$BASE/qemu.pid"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
RAM="${RAM:-$RAM_DEFAULT}"
CORES="$(nproc 2>/dev/null || echo 2)"
JOBS="${JOBS:-$([ "$CORES" -ge 4 ] && echo 3 || echo 2)}"

say()   { printf '\n==> %s\n' "$*"; }
pause() { if [ -t 0 ]; then echo; read -r -p "Press Enter to close..." _ || true; fi; }
fail()  { printf '\nERROR: %s\n' "$*" >&2; pause; exit 1; }

retry() {
  local n="$1" i
  shift
  for i in $(seq 1 "$n"); do
    "$@" && return 0
    echo "  (attempt $i/$n failed: $*)" >&2
    sleep 3
  done
  return 1
}

qemu_bin() {
  local f
  for f in "$SRC/build/arm-softmmu/qemu-system-arm" "$SRC/build/qemu-system-arm"; do
    if [ -x "$f" ]; then
      echo "$f"
      return 0
    fi
  done
  return 1
}

# ------------------------------------------------------------------ setup --

install_deps() {
  say "Step 1/5: installing packages"
  export DEBIAN_FRONTEND=noninteractive
  retry 3 pkg update -y || echo "WARNING: pkg update failed (continuing)"
  retry 2 pkg upgrade -y -o Dpkg::Options::="--force-confnew" \
    || echo "WARNING: pkg upgrade failed (continuing)"

  local p c m
  for p in git clang make ninja pkg-config python python-pip glib libpixman \
           openssl zlib curl unzip binutils perl; do
    retry 2 pkg install -y "$p" || echo "WARNING: could not install $p"
  done
  for c in git clang make ninja python curl unzip; do
    command -v "$c" >/dev/null 2>&1 \
      || fail "Required tool missing: $c. Check your internet connection and press Setup again."
  done

  for m in distlib setuptools wheel meson packaging; do
    pip install "$m" >/dev/null 2>&1 \
      || pip install --break-system-packages "$m" >/dev/null 2>&1 \
      || echo "WARNING: python module $m not installed"
  done
  command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock || true
}

get_source() {
  say "Step 2/5: getting the $NAME emulator source"
  if [ -d "$SRC/.git" ]; then
    echo "  already downloaded"
    return 0
  fi
  rm -rf "$SRC"
  retry 3 git clone --depth 1 -b "$BRANCH" https://github.com/devos50/qemu-ios.git "$SRC" \
    || fail "Could not download the source (branch $BRANCH). Check your internet connection and press Setup again."
}

apply_patches() {
  # Android's C library (bionic) has gettid(); SYS_gettid is not declared there.
  sed -i 's/syscall(SYS_gettid)/gettid()/' "$SRC/util/oslib-posix.c" 2>/dev/null || true
  # Extra patches can be dropped in ~/ios-qemu-patches.sh without rebuilding the app.
  if [ -f "$HOME/ios-qemu-patches.sh" ]; then
    # shellcheck disable=SC1090
    . "$HOME/ios-qemu-patches.sh" || true
  fi
}

# Newer Termux Python reports platform "Android"; QEMU's build system then does not treat the
# host as Linux (CONFIG_LINUX missing) and half of the Linux-only code breaks. Pretend it is Linux.
prepare_python_fix() {
  mkdir -p "$BASE/pyfix"
  cat > "$BASE/pyfix/sitecustomize.py" <<'PY'
import platform
platform.system = lambda: "Linux"
PY
  export PYTHONPATH="$BASE/pyfix${PYTHONPATH:+:$PYTHONPATH}"
}

run_configure() {
  # $@ = extra configure options
  rm -rf "$SRC/build"
  mkdir -p "$SRC/build"
  cd "$SRC/build" || return 1
  ../configure \
    --target-list=arm-softmmu \
    --disable-capstone \
    --disable-slirp \
    --disable-docs \
    --disable-werror \
    --enable-pie \
    "$@" \
    --extra-cflags="-I$PREFIX/include -DSG_ERR_DRIVER_TIMEOUT=0x06 -DSG_ERR_DRIVER_SENSE=0x08" \
    --extra-ldflags="-L$PREFIX/lib -lcrypto" 2>&1 | tee "$CFGLOG"
  [ -f "$SRC/build/build.ninja" ]
}

build_qemu() {
  if qemu_bin >/dev/null; then
    say "Step 3/5: emulator already built"
    return 0
  fi

  local free_kb
  free_kb=$(df -Pk "$BASE" | awk 'NR==2{print $4}')
  [ "${free_kb:-0}" -ge 5000000 ] \
    || fail "Need about 5 GB free storage; only $((free_kb/1024)) MB available."

  say "Step 3/5: configuring the emulator"
  apply_patches
  prepare_python_fix
  if [ ! -f "$MARK" ] || [ ! -f "$SRC/build/build.ninja" ]; then
    # Turn off optional libraries that Termux ships in versions this old QEMU cannot use.
    if ! run_configure --disable-libnfs --disable-libssh --disable-curl --disable-libusb \
                       --disable-linux-io-uring --disable-tools --disable-guest-agent; then
      echo "  configure with extra options failed; retrying with plain options"
      run_configure || {
        echo; echo "=== CONFIGURE ERROR (last lines) ==="
        tail -n 25 "$CFGLOG"
        fail "Configure failed. Send a screenshot of the lines above."
      }
    fi
    touch "$MARK"
  fi
  cd "$SRC/build" || fail "build directory missing"
  if grep -q 'define CONFIG_LINUX' config-host.h 2>/dev/null; then
    echo "  host detected as Linux: yes"
  else
    echo "  host detected as Linux: NO (some Linux-only code may fail to build)"
  fi

  say "Step 4/5: compiling (this takes a long time - keep the screen on and the phone charging)"
  local attempt j
  for attempt in 1 2; do
    apply_patches
    j="$JOBS"
    [ "$attempt" -eq 2 ] && j=1
    echo "  build attempt $attempt (using $j CPU cores)"
    make -k -j"$j" 2>&1 | tee "$LOG" \
      | grep --line-buffered -oE '^\[[0-9]+/[0-9]+\]' \
      | awk 'NR%40==1 { print "  progress " $0; fflush() }'
    if qemu_bin >/dev/null; then
      echo "  build finished"
      return 0
    fi
  done

  grep -E "error:" "$LOG" | sort -u > "$ERRFILE"
  echo; echo "=== FILES WITH ERRORS (count, file) ==="
  sed -E 's#^\.\./##; s#:[0-9]+:[0-9]+:.*##' "$ERRFILE" | sort | uniq -c | sort -rn | head -n 25
  echo; echo "=== FIRST ERRORS ==="
  head -n 12 "$ERRFILE" | cut -c1-150
  echo; echo "(full list: $ERRFILE)"
  fail "The emulator did not compile. Send a screenshot of the lists above."
}

fetch_assets() {
  say "Step 5/5: downloading the $NAME boot files"
  mkdir -p "$ASSETS" "$EXTRACT"
  cd "$ASSETS" || fail "assets directory missing"
  local urls u f z d
  urls=$(retry 3 curl -fsSL "https://api.github.com/repos/devos50/qemu-ios/releases/tags/$TAG" \
         | grep -o '"browser_download_url": *"[^"]*"' | cut -d'"' -f4) \
    || fail "Could not read the download list from GitHub."
  [ -n "$urls" ] || fail "The GitHub release has no files to download."
  for u in $urls; do
    f="$(basename "$u")"
    if [ ! -s "$f" ]; then
      echo "  downloading $f"
      retry 3 curl -fL -o "$f" "$u" || { rm -f "$f"; fail "Download failed: $f. Press Setup again."; }
    fi
  done
  for z in *.zip; do
    [ -e "$z" ] || continue
    d="$EXTRACT/${z%.zip}"
    [ -d "$d" ] || { mkdir -p "$d"; unzip -oq "$z" -d "$d" || fail "Could not unzip $z"; }
  done

  local bootrom iboot nand nor
  bootrom=$(find "$ASSETS" "$EXTRACT" -type f \( -iname '*bootrom*' -o -iname '*s5l8*' \) | head -n1 || true)
  nand=$(find "$EXTRACT" "$ASSETS" -type d -iname 'nand' | head -n1 || true)
  iboot=""
  if [ "$MODEL" = "1g" ]; then
    iboot=$(find "$ASSETS" "$EXTRACT" -type f -iname '*iboot*' | head -n1 || true)
    nor=$(find "$ASSETS" "$EXTRACT" -type f -iname '*nor*' ! -iname '*.zip' | head -n1 || true)
  else
    nor=$(find "$EXTRACT" "$ASSETS" -iname '*nor*' ! -iname '*.zip' | head -n1 || true)
  fi
  echo "  bootrom: ${bootrom:-NOT FOUND}"
  [ "$MODEL" = "1g" ] && echo "  iboot  : ${iboot:-NOT FOUND}"
  echo "  nand   : ${nand:-NOT FOUND}"
  echo "  nor    : ${nor:-NOT FOUND}"
  printf 'BOOTROM="%s"\nIBOOT="%s"\nNAND="%s"\nNOR="%s"\n' "$bootrom" "$iboot" "$nand" "$nor" > "$CONF"
  if [ -z "$bootrom" ] || [ -z "$nand" ] || [ -z "$nor" ] || { [ "$MODEL" = "1g" ] && [ -z "$iboot" ]; }; then
    echo; echo "Downloaded files:"
    ls -lR "$ASSETS" "$EXTRACT" | head -n 60
    fail "Could not recognise every boot file. Send a screenshot of the list above."
  fi
}

do_setup() {
  mkdir -p "$BASE"
  say "$NAME setup starts. It is safe to press Setup again if anything fails."
  install_deps
  get_source
  build_qemu
  fetch_assets
  say "ALL DONE ($NAME). Go back to the app and press Start, then Connect."
  pause
}

# -------------------------------------------------------------- run / stop --

do_run() {
  [ -f "$CONF" ] || fail "$NAME is not set up yet. Open Controls and press Setup."
  # shellcheck disable=SC1090
  . "$CONF"
  [ -n "${BOOTROM:-}" ] && [ -n "${NAND:-}" ] && [ -n "${NOR:-}" ] || fail "Bad paths in $CONF - press Setup again."
  local q
  q="$(qemu_bin)" || fail "The $NAME emulator is not built yet. Press Setup."

  if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    fail "An emulator is already running (pid $(cat "$PIDFILE")). Press Stop first."
  fi
  command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock || true

  say "Starting $NAME. VNC on 127.0.0.1:5901 - press Connect in the app."
  echo $$ > "$PIDFILE"
  if [ "$MODEL" = "1g" ]; then
    [ -n "${IBOOT:-}" ] || fail "iBoot file missing - press Setup again."
    exec "$q" \
      -M "iPod-Touch,bootrom=$BOOTROM,iboot=$IBOOT,nand=$NAND" \
      -serial mon:stdio -cpu max -m "$RAM" -d unimp \
      -pflash "$NOR" \
      -display none -vnc 127.0.0.1:1
  else
    exec "$q" \
      -M "iPod-Touch,bootrom=$BOOTROM,nand=$NAND,nor=$NOR" \
      -serial mon:stdio -cpu max -m "$RAM" -d unimp \
      -display none -vnc 127.0.0.1:1
  fi
}

do_stop() {
  if [ -f "$PIDFILE" ]; then
    kill "$(cat "$PIDFILE")" 2>/dev/null || true
    rm -f "$PIDFILE"
  fi
  command -v pkill >/dev/null 2>&1 && pkill -f qemu-system-arm 2>/dev/null || true
  command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock || true
  echo "Stopped."
}

case "${1:-}" in
  setup) do_setup ;;
  run)   do_run ;;
  stop)  do_stop ;;
  *)     echo "usage: setup | run | stop  [1g|2g]"; exit 1 ;;
esac
